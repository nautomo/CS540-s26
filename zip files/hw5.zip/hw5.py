# add your code to this file
import sys
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from numpy.linalg import inv #u can use this to compute the inverse of a matrix

if __name__ == "__main__":
    # Read in inputs
    filename = sys.argv[1]
    degree = int(sys.argv[2])
    learning_rate = float(sys.argv[3])
    iterations = int(sys.argv[4])