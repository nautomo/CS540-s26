import heapq
from itertools import permutations

def get_manhattan_distance(from_state, to_state=[1, 2, 3, 4, 5, 6, 7, 0, 0]):
    """
    TODO: implement this function. This function will not be tested directly by the grader. 

    INPUT: 
        Two states (if second state is omitted then it is assumed that it is the goal state)

    RETURNS:
        A scalar that is the sum of Manhattan distances for all tiles.
    """
    return distance

    
def get_euclidean_distance(from_state, to_state=(1,2,3,4,5,6,7,0,0)):
    """
    TODO: Implement this function. This function will not directly be tested by the grader.
    INPUT: 
        Two states (if second state is omitted then it is assumed that it is the goal state)

    RETURNS:
        A scalar that is the sum of Euclidean distances for all tiles.
    """
    return distance


def print_succ(state,heuristic):
    """
    TODO: This is based on get_succ function below, so should implement that function.

    INPUT: 
        A state (list of length 9)
        The hueristic to use ("manhattan" or "euclidean")

    WHAT IT DOES:
        Prints the list of all the valid successors in the puzzle. 
    """
    succ_states = get_succ(state,heuristic)

    for succ_state in succ_states:
        if heuristic == "manhattan":
            print(succ_state, "h={}".format(get_manhattan_distance(succ_state)))
        else:
            print(succ_state, "h={}".format(get_euclidean_distance(succ_state)))


def get_succ(state,heuristic):
    """
    TODO: implement this function.

    INPUT: 
        An initial state (list of length 9)
        The hueristic to use ("manhattan" or "euclidean")

    RETURNS:
        A list of all the valid successors in the puzzle (don't forget to sort the result as done below). 
    """
   
    return sorted(succ_states)
    

def solve(state, heuristic, silent, goal_state=[1, 2, 3, 4, 5, 6, 7, 0, 0]):
    """
    TODO: Implement the A* algorithm here.

    INPUT: 
        An initial state (list of length 9)
        The hueristic to use ("manhattan" or "euclidean")
        silent, which is False if the results are to be printed, and True if nothing should be printed

    WHAT IT SHOULD DO:
        Prints a path of configurations from initial state to goal state along  h values, number of moves, and max queue number in the format specified in the pdf.
    """

    # This is a format helper，which is only designed for format purpose.
    # build "state_info_list", for each "state_info" in the list, it contains "current_state", "h" and "move".
    # define and compute max length
    # it can help to avoid any potential format issue.
    if not silent:
        for state_info in state_info_list:
            current_state = state_info[0]
            h = state_info[1]
            move = state_info[2]
            print(current_state, "h={}".format(h), "moves: {}".format(move))
        print("Max queue length: {}".format(max_length))

    return max_length, nodes_expanded

def compare():
    """
    TODO: implement this function.

    WHAT IT DOES:
        Prints the average max queue length and average nodes expanded for A* with
        Manhattan and Euclidean heuristics across all 24 puzzles where the first 5
        values are [0, 0, 7, 6, 5]. Also includes a written explanation of which
        heuristic is more efficient and why.
    """

    prefix = [0, 0, 7, 6, 5]
    remaining = [1, 2, 3, 4]
    all_puzzles = [prefix + list(perm) for perm in permutations(remaining)]

    # TODO: solve each puzzle with both heuristics and collect results
    # hint: use the solve function with silent=True
    
    print("Manhattan Average Max Queue Length: {}".format(m_max_queue))
    print("Euclidean Average Max Queue Length: {}".format(e_max_queue))
    print("Manhattan Average Expanded: {}".format(m_expanded))
    print("Euclidean Average Expanded: {}".format(e_expanded))
    
    # TODO: print written explanation


if __name__ == "__main__":
    """
    Feel free to write your own test code here to exaime the correctness of your functions. 
    Note that this part will not be graded.
    """
    print_succ([3, 4, 6, 0, 0, 1, 7, 2, 5], 'manhattan')
    # print_succ([6, 0, 0, 3, 5, 1, 7, 2, 4], 'manhattan')
    # print_succ([0, 4, 7, 1, 3, 0, 6, 2, 5], 'manhattan')
    # print_succ([5, 2, 3, 0, 6, 4, 7, 1, 0], 'euclidean')
    # print_succ([1, 7, 0, 6, 3, 2, 0, 4, 5], 'euclidean')
    # solve([3, 4, 6, 0, 0, 1, 7, 2, 5],'manhattan',False)
    # solve([6, 0, 0, 3, 5, 1, 7, 2, 4],'manhattan',False)
    # solve([0, 4, 7, 1, 3, 0, 6, 2, 5],'manhattan',False)
    # solve([5, 2, 3, 0, 6, 4, 7, 1, 0],'euclidean',False)
    # solve([1, 7, 0, 6, 3, 2, 0, 4, 5],'euclidean',False)
    # compare()

